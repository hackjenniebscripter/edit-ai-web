# EDIT AI Web Prototype 0.2

Mobile-first browser prototype for anime edit effects.

## Run on Android
- Open `index.html` in a modern browser, or host the folder on a static web host.
- For best media APIs, use HTTPS hosting (for example, a static site host).
- Select a local video, choose a preset, adjust shake/flash/zoom, preview, and try recording the canvas output.
- Voice recognition depends on browser support and permissions.

## Current capabilities
- Local video selection and preview.
- Presets: Impact, Velocity, Dark AMV, Cinematic.
- Real-time canvas effects: shake, zoom, contrast/tint, flashes.
- Simple voice command recognition when supported.
- Browser-based recording/export of the rendered canvas as WebM when supported.

## Limitations
- This is an experimental prototype, not a native APK.
- It does not yet perform AI scene selection or reliable beat/onset detection; the plan uses a rough BPM estimate.
- Exported audio inclusion depends on browser support. The separate music file is previewed, but mixing it into the recorded export is not guaranteed.
- WebM is the likely output format; MP4 support is browser-dependent.
- This is not a clone of a specific creator's work; it provides general editing techniques.

## Next development steps
1. Add reliable audio beat detection (onset analysis).
2. Add speed ramps / velocity using a timeline.
3. Mix source audio or selected soundtrack into export consistently.
4. Implement real MP4 encoding and export settings.
5. Package as Android APK with a WebView wrapper or a native video processing engine.
